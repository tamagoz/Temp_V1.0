/*
 * BrokerConfig.h
 *
 *  Created on: Jul 24, 2558 BE
 *      Author: admin
 */

#include <SmingCore/SmingCore.h>

#ifndef APP_BROKERCONFIG_H_
#define APP_BROKERCONFIG_H_

#define BROKER_SETTINGS_FILE ".broker.conf" // leading point for security reasons :)

struct BrokerSettingsStorage
{
	bool active;
	String user_name;
	String password;
	String serverHost ;
	int serverPort;
	int updateInterval;
	int pinNumber;

	void load(){
		DynamicJsonBuffer jsonBuffer;
		if (exist())
		{
			Serial.println("Load broker configuration...");
			int size = fileGetSize(BROKER_SETTINGS_FILE);
			char* jsonString = new char[size + 1];
			fileGetContent(BROKER_SETTINGS_FILE, jsonString, size + 1);
			JsonObject& root = jsonBuffer.parseObject(jsonString);

			JsonObject& broker = root["broker"];
			active = broker["active"];
			user_name = broker["user_name"].toString();
			password = broker["password"].toString();
			serverHost = broker["host"].toString();
			serverPort = broker["port"].toString().toInt();
			updateInterval = broker["interval"].toString().toInt();
			pinNumber = broker["pin"].toString().toInt();

			Serial.println("User: "+ user_name);
			Serial.println("Password: "+ password);
			Serial.println("Host: "+ serverHost);
			Serial.println("Port: "+ String(serverPort));
			Serial.println("Interval: "+ String(updateInterval));
			Serial.println("Pin: "+ String(pinNumber));

			delete[] jsonString;
		}else{
			Serial.println("Load default broker configuration...");
			serverHost = "ratchasak.me";
			serverPort = 1883;
			updateInterval = 10;
			pinNumber = 5;
			active = false;
		}
	}

	void save(){
		DynamicJsonBuffer jsonBuffer;
		JsonObject& root = jsonBuffer.createObject();

		JsonObject& broker = jsonBuffer.createObject();
		root["broker"] = broker;
		broker["active"] = active;
		broker["user_name"] = user_name.c_str();
		broker["password"] = password.c_str();
		broker["host"] = serverHost.c_str();
		broker.addCopy("port", String(serverPort));
		broker.addCopy("interval", String(updateInterval));
		broker.addCopy("pin", String(pinNumber));
		//TODO: add direct file stream writing
		fileSetContent(BROKER_SETTINGS_FILE, root.toJsonString());
	}

	bool exist() { return fileExist(BROKER_SETTINGS_FILE); }
};

static BrokerSettingsStorage BrokerSettings;

#endif /* APP_BROKERCONFIG_H_ */
