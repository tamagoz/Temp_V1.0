#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

#ifdef __cplusplus
extern "C" {
#endif
//#ifndef LCD_DISPLAY
	#define INT_PIN 4   // GPIO4
	#define CONF_PIN 5	// GPIO5
//----------------------------------------------
//wemos1,2,3,4
	//#define WIFI_SSID "mybycat-D40A"
	//#define WIFI_PWD "32503197"
//wemos5,6
	#define WIFI_SSID "mybycat-D9AA"
	#define WIFI_PWD "32503437"
//wemos7,8,9,10
	//#define WIFI_SSID "mybycat-F53E"
	//#define WIFI_PWD "41802946"
// wemos11,wemos12
	//#define WIFI_SSID "mybycat-D40A"
	//#define WIFI_PWD "32503197"
//----------------------------------------------
// UART config
	#define SERIAL_BAUD_RATE 115200

	// ESP SDK config
	#define LWIP_OPEN_SRC
	#define USE_US_TIMER

	// Default types
	#define __CORRECT_ISO_CPP_STDLIB_H_PROTO
	#include <limits.h>
	#include <stdint.h>

	// Override c_types.h include and remove buggy espconn
	#define _C_TYPES_H_
	#define _NO_ESPCON_

	// Updated, compatible version of c_types.h
	// Just removed types declared in <stdint.h>
	#include <espinc/c_types_compatible.h>

	// System API declarations
	#include <esp_systemapi.h>

	// C++ Support
	#include <esp_cplusplus.h>
	// Extended string conversion for compatibility
	#include <stringconversion.h>
	// Network base API
	#include <espinc/lwip_includes.h>

	// Beta boards
	#define BOARD_ESP01

#ifdef __cplusplus
}
#endif

#endif
