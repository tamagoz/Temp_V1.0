/*
 * mqtt_server.cpp
 *
 *  Created on: Jul 29, 2558 BE
 *      Author: admin
 */
#include <application.h>

MqttClient *mqtt;
Timer procTimer;
String inTopic  = "devices/55b0a8e0cc2c1054ff0022ab/get";
String outTopic = "devices/55b0a8e0cc2c1054ff0022ab/set";
float CalibrateValueTemp = 0;
float CalibrateValueHumi = 0;
//--------------------------------------------------------
//String SENSOR_ID = "Sensor1";
//String SENSOR_ID = "9708a805-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor2";
//String SENSOR_ID = "9708a806-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor3";
String SENSOR_ID = "9708a807-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor4";
//String SENSOR_ID = "9708a808-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor5";
//String SENSOR_ID = "9708a809-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor6";
//String SENSOR_ID = "9708a810-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor7";
//String SENSOR_ID = "9708a811-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor8";
//String SENSOR_ID = "9708a812-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor9";
//String SENSOR_ID = "9708a813-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor10";
//String SENSOR_ID = "9708a814-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor11";
//String SENSOR_ID = "9708a815-1f15-11e6-a724-a34111381c19";

//String SENSOR_ID = "Sensor12";
//String SENSOR_ID = "9708a816-1f15-11e6-a724-a34111381c19";

//-------------------------------------------------------
String TOPIC = "/sensors/all/set";
// Publish our message
bool brokerActive = false;




void publishMessage(float t, float h)
{
	if (isnan(t) || isnan(h))
	{
		Serial.println("Failed read DHT");
		//readDhtFailed();
	} else {
		t = t - CalibrateValueTemp;
		h = h - CalibrateValueHumi;
		DateTime _datetime = SystemClock.now(eTZ_Local);
		long timestamp = (long)_datetime.toUnixTime();
		String strTimestamp = String(timestamp);

		String message = "";
		message += "{";
		message +=		"\"time\":\""+ strTimestamp +"\",";
		message +=		"\"sensorId\":\""+SENSOR_ID+"\",";
		message +=		"\"wifiId\":\""+deviceId+"\",";
		message +=		"\"type\":1,";
		message +=		"\"sensors\":[";
		message +=			"{";
		message +=				"\"type\":\"temp\",";
		message +=				"\"value\":\"" + String(t) + "\"";
		message +=				",\"measurement_id\":\"temp1\"";
		message +=			"},";
		message +=			"{";
		message +=				"\"type\":\"humid\",";
		message +=				"\"value\":\"" + String(h) + "\"";
		message +=				",\"measurement_id\":\"humid1\"";
		message +=			"}";
		message +=		"]";
		message +=	"}";
		Serial.println(message);
		sendSocketClient(message);

		if (brokerActive){
			if (mqtt->getConnectionState() == TcpClientState::eTCS_Connected){
				//mqtt->publish(deviceId + "/"+ BrokerSettings.user_name +"/temperature", message);
				mqtt->publish(TOPIC, message);
//				Serial.println("Let's publish message now!");
			}else{
				BrokerSettings.load();
				Serial.println("MQTT client disconnected!");
				mqtt->connect(deviceId, BrokerSettings.user_name, BrokerSettings.password);
				//mqtt->subscribe(inTopic);
				//mqtt->subscribe(outTopic);
				Serial.println("MQTT client reconnect");
			}
		}
	}
}

// Callback for messages, arrived from MQTT server
void onMessageReceived(String topic, String message)
{
	//Serial.println();
	//Serial.print(topic);
	//Serial.print(" : "); // Prettify alignment for printing
	//Serial.println(message+"\r\n********************************\r\n");

	DynamicJsonBuffer jsonBuffer;
	char* jsonString = new char[message.length()+1];
	message.toCharArray(jsonString, message.length()+1);
	JsonObject& root = jsonBuffer.parseObject(jsonString);
	//Serial.println(root.toJsonString());
	String id = root["properties"][0]["id"].toString();
	String value = root["properties"][0]["value"].toString();

	//Serial.print("id : ");
	//Serial.println(id);
	//Serial.print("value : ");
	//Serial.println(value);

	int state = LOW;
	int gpio;
	if (topic == inTopic){
		//Serial.println("In Topic");
		if (id == "55b0a8e0cc2c1054ff0022ab"){
			state = value == "on" ? HIGH : LOW;
			gpio = 4;
		}
		digitalWrite(gpio, state);
		// websocket broadcast io status
		String st = digitalRead(gpio)?"1":"0";
		String msg = "{ \"Type\": 2, \"gpio\": " + String(gpio) + ", \"status\": " + st  + " }";
		sendSocketClient(msg);
	}

	if (topic == outTopic){
		//Serial.println("Out Topic");
	}

	delete jsonString;
}


void startMQTT()
{
	BrokerSettings.load();
	brokerActive = BrokerSettings.active;
	Serial.println("Start MQTT Server");
	Serial.println("Host: "+ BrokerSettings.serverHost);
	Serial.println("Port: "+ String(BrokerSettings.serverPort));
	Serial.println("Interval: "+ String(BrokerSettings.updateInterval));
	Serial.println("Pin: "+ String(BrokerSettings.pinNumber));

	if (brokerActive){
		mqtt = new MqttClient(BrokerSettings.serverHost, BrokerSettings.serverPort, onMessageReceived);
		// Run MQTT client
		mqtt->connect(deviceId, BrokerSettings.user_name, BrokerSettings.password);
		//mqtt->subscribe(inTopic);
		//mqtt->subscribe(outTopic);
		//publishMessage();
		Serial.println("Started MQTT Server");
		}
	// Start publishing loop
//	procTimer.initializeMs(BrokerSettings.updateInterval * 1000, publishMessage).start(); // every 5 seconds
}



