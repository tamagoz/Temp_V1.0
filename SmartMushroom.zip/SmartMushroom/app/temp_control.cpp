/*
 * temp_control.cpp
 *
 *  Created on: Aug 1, 2558 BE
 *      Author: admin
 */

#include <application.h>

Timer tempTimer;
int tempMin;
int tempMax;
int humiMin;
int humiMax;
int interval;
bool mode;



void sendSocket(int gpio)
{
	// websocket broadcast io status
	String st = digitalRead(gpio)?"1":"0";
	String msg = "{ \"Type\": 2, \"gpio\": " + String(gpio) + ", \"status\": " + st  + " }";
	sendSocketClient(msg);
}

bool humiNormal(float h)
{
	return ((h >= humiMin) && (h <= humiMax));
}

bool tempNormal(float t)
{
	return ((t >= tempMin) && (t <= tempMax));
}

void LEDoN()	//LED ON
{
	if (digitalRead(16) == LOW){
		digitalWrite(16,  HIGH);
			//sendSocket(4);
	}
}
void LEDoFF()	//LED OFF
{
	if (digitalRead(16) == HIGH){
		digitalWrite(16,  LOW);
		//sendSocket(13);
	}
}
void BUZZERoN()	//BUZZER ON
{
	if (digitalRead(0) == HIGH){
		digitalWrite(0,  LOW);
		//sendSocket(4);
		}
}
void BUZZERoFF()	//BUZZER OFF
{
	if (digitalRead(0) == LOW){
		digitalWrite(0,  HIGH);
		//sendSocket(13);
		}
}

void processTemp(float t, float h)
{
	HttpClient downloadClient;
	// GPIO12  = LED
	// GPIO13  = BUZZER

	if ( (t > tempMax) && (h > humiMax) ){
		LEDoN();
		BUZZERoN();
	}

	if ( (t > tempMax) && (humiNormal(h)) ){
		LEDoN();
		BUZZERoN();
	}

	if ( (t > tempMax) && (h < humiMin) ){
		LEDoN();
		BUZZERoN();
	}

	// ************************************


	if ( tempNormal(t) && (h >= humiMax) ){
		LEDoN();
		BUZZERoN();
	}

	if ( tempNormal(t) && humiNormal(h) ){			//OFF Alarm,LED
		LEDoFF();
		BUZZERoFF();
	}

	if ( tempNormal(t) && (h <= humiMin) ){
		LEDoN();
		BUZZERoN();
	}

	// *************************************
	if ( (t <= tempMin) && (h >= humiMax) ){
		LEDoN();
		BUZZERoN();
	}

	if ( (t <= tempMin) && humiNormal(h) ){
		LEDoN();
		BUZZERoN();
	}

   if ( (t <= tempMin) && (h <= humiMin) ){
	   LEDoN();
	   BUZZERoN();
   }
}

void runInterval()
{
	if ((TempSettings.humiMin == 0) ||
			(TempSettings.humiMin == 0) ||
			(TempSettings.humiMin == 0) ||
			(TempSettings.humiMin == 0)){
		Serial.println("Temperature config not found!");
		return;
	}
	float h = dht->readHumidity();
	float t = dht->readTemperature();
	if (isnan(t) || isnan(h))
	{
		Serial.println("Failed read DHT");
		readDhtFailed();

	}else{
		lcdPrint(t, h);
		//if (readyToRun){
		publishMessage(t, h);
		//}
		//if (mode){
		processTemp(t, h);
		//}
	}
}

void loadMonitorConfig()
{
	TempSettings.load();
	tempMin = TempSettings.tempMin;
	tempMax = TempSettings.tempMax;
	humiMin = TempSettings.humiMin;
	humiMax = TempSettings.humiMax;
	interval = TempSettings.interval;
	mode = TempSettings.mode;
}

void startMonitor()
{
	loadMonitorConfig();

	Serial.println("Starting temperature monitoring: " + String(TempSettings.interval));
	tempTimer.initializeMs(interval * 1000, runInterval).start();
}


