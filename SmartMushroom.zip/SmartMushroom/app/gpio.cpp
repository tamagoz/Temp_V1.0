/*
 * gpio.cpp
 *
 *  Created on: Jul 29, 2558 BE
 *      Author: admin
 */

#include <application.h>

bool state = true;

void blink()
{
	digitalWrite(CONF_PIN, state);
	state = !state;
}

void init_gpio()
{
	pinMode(0, OUTPUT);
	pinMode(16, OUTPUT);
	digitalWrite(0, HIGH);
	digitalWrite(16, HIGH);
}


